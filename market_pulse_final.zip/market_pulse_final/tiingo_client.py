import json
import logging
import threading
import time
from datetime import datetime, timezone
from typing import Callable, Dict, Iterable, List, Optional

import requests
import websocket

log = logging.getLogger(__name__)

REST_BASE = "https://api.tiingo.com"
WS_EQUITY = "wss://api.tiingo.com/equity/intraday"


class TiingoREST:
    def __init__(self, token: str, timeout: int = 20):
        self.token = token
        self.timeout = timeout
        self.session = requests.Session()
        self.session.headers.update({"Authorization": f"Token {token}"})
        self.backoff_until = 0.0
        self.last_error: Optional[str] = None
        self.request_count = 0

    def _get(self, path: str, params: Optional[dict] = None):
        now = time.time()
        if now < self.backoff_until:
            raise RuntimeError(f"REST backoff active for {self.backoff_until-now:.0f}s")
        self.request_count += 1
        r = self.session.get(REST_BASE + path, params=params, timeout=self.timeout)
        if r.status_code == 429:
            retry = int(r.headers.get("Retry-After", "120") or 120)
            retry = max(60, min(retry, 900))
            self.backoff_until = time.time() + retry
            self.last_error = f"HTTP 429; backing off {retry}s"
            raise RuntimeError(self.last_error)
        r.raise_for_status()
        self.last_error = None
        return r.json()

    def all_equity_snapshots(self):
        return self._get("/tiingo/equity/intraday")

    def ticker_bars(self, ticker: str, start_date: str, resample: str = "5min"):
        return self._get(
            f"/tiingo/equity/intraday/{ticker}/prices",
            params={
                "startDate": start_date,
                "resampleFreq": resample,
                "columns": "open,high,low,close,volume",
                "afterHours": "true",
            },
        )

    def latest_news(self, limit: int = 100):
        return self._get("/tiingo/news", params={"sortBy": "crawlDate", "limit": limit})


class TiingoRealtimeWS:
    """Persistent Tiingo consolidated-equity reference-price stream."""

    def __init__(self, token: str, on_price: Callable[[str, float, str], None], on_status=None):
        self.token = token
        self.on_price = on_price
        self.on_status = on_status or (lambda *_: None)
        self._thread: Optional[threading.Thread] = None
        self._stop = threading.Event()
        self._tickers: List[str] = []
        self._lock = threading.Lock()
        self.ws: Optional[websocket.WebSocketApp] = None
        self.connected = False
        self.last_message_at: Optional[float] = None
        self.last_error: Optional[str] = None

    def set_tickers(self, tickers: Iterable[str]):
        clean = sorted({str(t).upper().strip() for t in tickers if t})
        with self._lock:
            changed = clean != self._tickers
            self._tickers = clean
        if changed and self.connected and self.ws:
            try:
                self._send_subscribe(self.ws)
            except Exception as e:
                self.last_error = str(e)

    def start(self):
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._run, daemon=True, name="tiingo-ws")
        self._thread.start()

    def stop(self):
        self._stop.set()
        if self.ws:
            try:
                self.ws.close()
            except Exception:
                pass

    def _send_subscribe(self, ws):
        with self._lock:
            tickers = list(self._tickers)
        payload = {
            "eventName": "subscribe",
            "authorization": self.token,
            "eventData": {"thresholdLevel": 6, "tickers": tickers},
        }
        ws.send(json.dumps(payload))
        self.on_status("subscribed", len(tickers))

    def _run(self):
        delay = 2
        while not self._stop.is_set():
            try:
                self.on_status("connecting", 0)

                def on_open(ws):
                    self.connected = True
                    self.last_error = None
                    self.on_status("connected", 0)
                    self._send_subscribe(ws)

                def on_message(ws, raw):
                    self.last_message_at = time.time()
                    try:
                        msg = json.loads(raw)
                    except Exception:
                        return
                    if msg.get("messageType") == "A" and msg.get("service") == "cons":
                        data = msg.get("data") or []
                        if len(data) >= 3:
                            ts, ticker, price = data[0], str(data[1]).upper(), data[2]
                            try:
                                self.on_price(ticker, float(price), ts)
                            except Exception:
                                return
                    elif msg.get("messageType") in {"E", "I"}:
                        self.on_status("message", msg)

                def on_error(ws, error):
                    self.last_error = str(error)
                    self.on_status("error", str(error))

                def on_close(ws, code, reason):
                    self.connected = False
                    self.on_status("closed", {"code": code, "reason": reason})

                self.ws = websocket.WebSocketApp(
                    WS_EQUITY,
                    on_open=on_open,
                    on_message=on_message,
                    on_error=on_error,
                    on_close=on_close,
                )
                self.ws.run_forever(ping_interval=25, ping_timeout=10)
            except Exception as e:
                self.last_error = str(e)
                self.on_status("error", str(e))
            self.connected = False
            if self._stop.wait(delay):
                return
            delay = min(delay * 2, 60)
