import math
import os
import threading
import time
from collections import defaultdict, deque
from dataclasses import dataclass, asdict
from datetime import datetime, timedelta, timezone
from statistics import median
from typing import Dict, List, Optional

from tiingo_client import TiingoREST, TiingoRealtimeWS

CATALYST_WORDS = {
    "FDA": ["fda", "fast track", "breakthrough therapy", "approval", "phase 3", "phase iii"],
    "CONTRACT": ["contract", "award", "awarded", "purchase order", "government", "department of defense"],
    "M&A": ["acquire", "acquisition", "merger", "takeover", "buyout"],
    "PARTNERSHIP": ["partnership", "partner", "strategic collaboration", "agreement"],
    "EARNINGS": ["earnings", "revenue", "guidance", "raises outlook", "beats estimates"],
}


@dataclass
class Candidate:
    ticker: str
    price: float
    change_pct: float
    volume: int
    one_min_pct: float
    five_min_pct: float
    dist_high_pct: float
    volume_burst: float
    score: float
    state: str
    breakout: bool
    catalyst: str = ""
    news_title: str = ""
    timestamp: str = ""


class MarketPulseScanner:
    def __init__(self, token: str):
        self.rest = TiingoREST(token)
        self.lock = threading.RLock()
        self.snapshots: Dict[str, dict] = {}
        self.prev_snapshot_volume: Dict[str, int] = {}
        self.volume_delta: Dict[str, int] = {}
        self.price_history = defaultdict(lambda: deque(maxlen=600))  # (epoch, price)
        self.news_by_ticker: Dict[str, dict] = {}
        self.candidates: List[Candidate] = []
        self.alerts: deque = deque(maxlen=200)
        self.alerted: Dict[str, float] = {}
        self.symbols_subscribed = 0
        self.symbols_live = set()
        self.last_snapshot_at = 0.0
        self.last_news_at = 0.0
        self.ws_status = "starting"
        self.ws_detail = None
        self.thread = None
        self.stop_evt = threading.Event()
        self.ws = TiingoRealtimeWS(token, self._on_price, self._on_ws_status)

    def start(self):
        if self.thread and self.thread.is_alive():
            return
        self.stop_evt.clear()
        self.thread = threading.Thread(target=self._loop, daemon=True, name="scanner-loop")
        self.thread.start()

    def stop(self):
        self.stop_evt.set()
        self.ws.stop()

    def _on_ws_status(self, status, detail):
        with self.lock:
            self.ws_status = status
            self.ws_detail = detail

    def _on_price(self, ticker: str, price: float, ts: str):
        now = time.time()
        with self.lock:
            self.symbols_live.add(ticker)
            hist = self.price_history[ticker]
            if not hist or now - hist[-1][0] >= 1.0 or abs(price / hist[-1][1] - 1) >= 0.0005:
                hist.append((now, price))
            if ticker in self.snapshots:
                s = self.snapshots[ticker]
                s["tngoLast"] = price
                s["timestamp"] = ts
                high = s.get("high")
                if high is None or price > high:
                    s["high"] = price
        # Calculation is cheap enough to do at most every few seconds from loop, not per tick.

    def _loop(self):
        next_snapshot = 0
        next_news = 0
        next_rank = 0
        while not self.stop_evt.is_set():
            now = time.time()
            if now >= next_snapshot:
                ok = self._refresh_all_snapshots()
                next_snapshot = now + (90 if ok else 180)
            if now >= next_news:
                self._refresh_news_best_effort()
                next_news = now + 120
            if now >= next_rank:
                self._rank_candidates()
                next_rank = now + 3
            self.stop_evt.wait(0.5)

    def _refresh_all_snapshots(self) -> bool:
        try:
            rows = self.rest.all_equity_snapshots()
            if not isinstance(rows, list):
                return False
            tickers = []
            with self.lock:
                for row in rows:
                    ticker = str(row.get("ticker", "")).upper().strip()
                    price = row.get("tngoLast")
                    prev = row.get("prevClose")
                    if not ticker or price is None or prev in (None, 0):
                        continue
                    oldv = int(self.snapshots.get(ticker, {}).get("volume") or 0)
                    newv = int(row.get("volume") or 0)
                    self.volume_delta[ticker] = max(0, newv - oldv) if oldv else 0
                    self.prev_snapshot_volume[ticker] = oldv
                    self.snapshots[ticker] = row
                    tickers.append(ticker)
                    if not self.price_history[ticker]:
                        self.price_history[ticker].append((time.time(), float(price)))
                self.last_snapshot_at = time.time()
                self.symbols_subscribed = len(tickers)
            self.ws.set_tickers(tickers)
            self.ws.start()
            return True
        except Exception:
            return False

    def _refresh_news_best_effort(self):
        try:
            rows = self.rest.latest_news(limit=100)
        except Exception:
            return
        cutoff = datetime.now(timezone.utc) - timedelta(minutes=45)
        fresh = {}
        for row in rows if isinstance(rows, list) else []:
            crawl = row.get("crawlDate") or row.get("publishedDate")
            try:
                dt = datetime.fromisoformat(str(crawl).replace("Z", "+00:00"))
            except Exception:
                continue
            if dt < cutoff:
                continue
            text = f"{row.get('title','')} {row.get('description','')}".lower()
            cat = ""
            for label, words in CATALYST_WORDS.items():
                if any(w in text for w in words):
                    cat = label
                    break
            if not cat:
                continue
            for t in row.get("tickers") or []:
                t = str(t).upper()
                cur = fresh.get(t)
                if not cur or str(crawl) > str(cur.get("crawlDate", "")):
                    fresh[t] = {**row, "category": cat}
        with self.lock:
            self.news_by_ticker.update(fresh)
            self.last_news_at = time.time()

    @staticmethod
    def _price_at(hist, seconds_ago: int, now: float):
        target = now - seconds_ago
        best = None
        for t, p in hist:
            if t <= target:
                best = p
            else:
                break
        return best if best is not None else (hist[0][1] if hist else None)

    def _rank_candidates(self):
        now = time.time()
        with self.lock:
            rows = []
            deltas = [v for v in self.volume_delta.values() if v > 0]
            med_delta = median(deltas) if deltas else 1
            for ticker, s in self.snapshots.items():
                try:
                    price = float(s.get("tngoLast"))
                    prev = float(s.get("prevClose"))
                    high = float(s.get("high") or price)
                    volume = int(s.get("volume") or 0)
                except Exception:
                    continue
                if price <= 0 or prev <= 0 or volume < 50_000:
                    continue
                change = (price / prev - 1) * 100
                if change < 2.0:
                    continue
                hist = self.price_history.get(ticker)
                if not hist:
                    continue
                p1 = self._price_at(hist, 60, now)
                p5 = self._price_at(hist, 300, now)
                one = ((price / p1 - 1) * 100) if p1 else 0.0
                five = ((price / p5 - 1) * 100) if p5 else 0.0
                dist_high = max(0.0, (high - price) / high * 100) if high else 99
                vdelta = self.volume_delta.get(ticker, 0)
                burst = vdelta / max(med_delta, 1)
                breakout = dist_high <= 0.6 and (one >= 0.4 or five >= 1.0)

                # Score favors early move + acceleration + volume + high proximity.
                score = 0.0
                score += min(max(change - 2, 0), 10) * 3.0
                score += min(max(one, 0), 5) * 8.0
                score += min(max(five, 0), 10) * 3.0
                score += min(math.log1p(max(burst, 0)), 3) * 10.0
                score += max(0, 2.0 - dist_high) * 8.0
                if breakout:
                    score += 12
                news = self.news_by_ticker.get(ticker)
                if news:
                    score += 15

                if change >= 20 or five >= 12:
                    state = "EXTENDED"
                elif change <= 10 and (one >= 0.3 or five >= 0.8 or burst >= 2):
                    state = "EARLY"
                else:
                    state = "CONFIRMING"

                # Candidate floor. Keep loose enough to show diagnostics.
                if score < 16:
                    continue
                rows.append(Candidate(
                    ticker=ticker,
                    price=price,
                    change_pct=change,
                    volume=volume,
                    one_min_pct=one,
                    five_min_pct=five,
                    dist_high_pct=dist_high,
                    volume_burst=burst,
                    score=score,
                    state=state,
                    breakout=breakout,
                    catalyst=(news or {}).get("category", ""),
                    news_title=(news or {}).get("title", ""),
                    timestamp=str(s.get("timestamp") or ""),
                ))
            rows.sort(key=lambda x: x.score, reverse=True)
            self.candidates = rows[:100]
            self._emit_alerts(rows[:25], now)

    def _emit_alerts(self, rows: List[Candidate], now: float):
        for c in rows:
            if c.state == "EXTENDED":
                continue
            # Require stronger early evidence for an alert than for table inclusion.
            qualifies = (
                c.change_pct >= 3.0
                and c.volume >= 100_000
                and c.dist_high_pct <= 2.0
                and (c.one_min_pct >= 0.5 or c.five_min_pct >= 1.2 or c.volume_burst >= 2.0 or bool(c.catalyst))
            )
            if not qualifies:
                continue
            last = self.alerted.get(c.ticker, 0)
            if now - last < 20 * 60:
                continue
            self.alerted[c.ticker] = now
            self.alerts.appendleft({**asdict(c), "alert_time": datetime.now(timezone.utc).isoformat()})

    def status(self):
        with self.lock:
            return {
                "ws_status": self.ws_status,
                "ws_connected": self.ws.connected,
                "symbols_subscribed": self.symbols_subscribed,
                "symbols_live": len(self.symbols_live),
                "snapshots": len(self.snapshots),
                "candidates": len(self.candidates),
                "rest_requests": self.rest.request_count,
                "rest_error": self.rest.last_error,
                "last_snapshot_at": self.last_snapshot_at,
                "last_news_at": self.last_news_at,
            }

    def get_candidates(self, limit=30):
        with self.lock:
            return [asdict(x) for x in self.candidates[:limit]]

    def get_alerts(self, limit=30):
        with self.lock:
            return list(self.alerts)[:limit]
