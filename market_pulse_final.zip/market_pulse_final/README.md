# Market Pulse Final

A self-contained early-momentum scanner for U.S. equities using Tiingo's consolidated Equity Realtime API.

## What it does

- Uses the **all-ticker consolidated snapshot** to discover the active U.S. equity universe dynamically.
- Maintains one persistent **Tiingo Equity Realtime WebSocket** for price updates.
- Keeps a rolling local cache for 1-minute/5-minute acceleration.
- Refreshes the all-ticker snapshot every ~90 seconds for prior close, day high/low and consolidated volume, with 429 backoff.
- Ranks **Fresh Movers** rather than biggest gainers only.
- Marks movers `EARLY`, `CONFIRMING`, or `EXTENDED` and suppresses alerts on extended moves.
- Best-effort Tiingo News catalyst tagging; gracefully continues if the account does not include News API access.
- Does **not** execute trades.

## Environment

Set this secret/environment variable:

`TIINGO_API_TOKEN`

Never hard-code the token in source code.

## Run

```bash
pip install -r requirements.txt
streamlit run app.py --server.address 0.0.0.0 --server.port 8501
```

## Notes on RVOL

True historical RVOL for thousands of symbols is intentionally not faked. The scanner uses cross-sectional **volume burst** from changes in consolidated volume snapshots as a fast discovery feature. Historical RVOL can be added only for the small candidate set later, avoiding thousands of REST calls and 429s.

## Data source behavior

Tiingo documents the consolidated Equity Realtime API as beta, available by REST and WebSocket from 4am–8pm ET. The WebSocket threshold level 6 stream emits consolidated reference-price updates. The all-ticker REST snapshot provides `prevClose`, day OHLC and `volume`.
