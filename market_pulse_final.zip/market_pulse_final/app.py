import os
import time
from datetime import datetime, timezone

import pandas as pd
import streamlit as st

from scanner import MarketPulseScanner

st.set_page_config(page_title="Market Pulse", page_icon="📡", layout="wide")

TOKEN = os.getenv("TIINGO_API_TOKEN", "").strip()

st.title("📡 Market Pulse — Early Movers")
st.caption("Tiingo realtime scanner • early momentum first • no trade execution")

if not TOKEN:
    st.error("TIINGO_API_TOKEN is not set in the environment.")
    st.stop()

@st.cache_resource
def get_scanner(token: str):
    s = MarketPulseScanner(token)
    s.start()
    return s

scanner = get_scanner(TOKEN)
status = scanner.status()

c1, c2, c3, c4, c5 = st.columns(5)
c1.metric("WebSocket", "CONNECTED" if status["ws_connected"] else status["ws_status"].upper())
c2.metric("Subscribed", f"{status['symbols_subscribed']:,}")
c3.metric("Live symbols", f"{status['symbols_live']:,}")
c4.metric("Fresh candidates", status["candidates"])
c5.metric("REST calls", status["rest_requests"])

if status.get("rest_error"):
    st.warning(status["rest_error"])

st.subheader("🚨 Alerts")
alerts = scanner.get_alerts(25)
if alerts:
    adf = pd.DataFrame(alerts)
    show_cols = ["ticker","state","price","change_pct","one_min_pct","five_min_pct","volume","volume_burst","dist_high_pct","breakout","catalyst","news_title","score","alert_time"]
    adf = adf[[c for c in show_cols if c in adf.columns]]
    st.dataframe(adf, use_container_width=True, hide_index=True)
else:
    st.info("0 qualifying early alerts right now. Extended movers are intentionally suppressed.")

st.subheader("⚡ Fresh Movers")
rows = scanner.get_candidates(40)
if rows:
    df = pd.DataFrame(rows)
    for col in ["change_pct","one_min_pct","five_min_pct","dist_high_pct","volume_burst","score"]:
        if col in df:
            df[col] = df[col].round(2)
    st.dataframe(df, use_container_width=True, hide_index=True)
else:
    st.info("Scanner is live but no symbols currently meet the candidate floor.")

st.subheader("Diagnostics")
st.json(status)

st.caption("Auto-refreshes every 5 seconds. Tiingo consolidated Equity Realtime operates 4am–8pm ET; news availability depends on account entitlement.")
time.sleep(5)
st.rerun()
